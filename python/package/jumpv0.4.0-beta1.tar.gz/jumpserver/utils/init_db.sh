#!/bin/bash
#

python ../apps/manage.py loaddata init
