#!/bin/bash
#

cd ..
docker build -t jumpserver/jumpserver:v0.4.0-beta1 .