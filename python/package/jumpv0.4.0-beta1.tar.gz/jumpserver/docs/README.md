#### [项目结构描述](https://code.simcu.com/jumpserver/jumpserver/blob/master/docs/project_structure.md)
#### [Python代码规范](https://code.simcu.com/jumpserver/jumpserver/blob/master/docs/python_style_guide.md)
#### [API设计规范](https://code.simcu.com/jumpserver/jumpserver/blob/master/docs/api_style_guide.md)
#### [表结构](https://code.simcu.com/jumpserver/jumpserver/wikis/table_structure_image)